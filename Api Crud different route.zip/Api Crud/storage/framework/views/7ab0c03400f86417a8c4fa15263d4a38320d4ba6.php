<h1>
    Please Check Your Api Key and Try again
</h1><?php /**PATH /opt/lampp/htdocs/Prince/Demo/Api Crud/resources/views/error.blade.php ENDPATH**/ ?>